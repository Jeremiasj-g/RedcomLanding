'use client';

import { AnimatePresence, motion } from 'framer-motion';
import { CalendarDays, Check, Clock, Loader2, Save } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import type { Task } from '@/lib/tasks';
import { supabase } from '@/lib/supabaseClient';
import TaskChecklistSection from '../TaskChecklistSection';
import { buildISOFromLocal, toYMD } from '../date';

// shadcn/ui
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/components/ui/command';

type Props = {
  task: Task | null;
  briefStatusLabel: (status: Task['status']) => string;
  onClose: () => void;
  onTaskUpdate: (next: Task) => void;
  onAllDone: (task: Task) => Promise<Task>;
};

function hhmmLocal(iso: string) {
  const d = new Date(iso);
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  return `${hh}:${mm}`;
}

function buildTimeOptions(stepMinutes = 30) {
  const out: string[] = [];
  for (let h = 0; h < 24; h++) {
    for (let m = 0; m < 60; m += stepMinutes) {
      out.push(`${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`);
    }
  }
  return out;
}

function normalizeTimeInput(raw: string) {
  // Permite: "13" → 13:00 | "9" → 09:00 | "1330" → 13:30 | "13:3" → 13:30 (si es múltiplo)
  const v = raw.trim();
  if (!v) return '';

  // si ya viene HH:MM válido
  const m = v.match(/^(\d{1,2}):(\d{1,2})$/);
  if (m) {
    const hh = Math.min(23, Math.max(0, Number(m[1])));
    const mm = Math.min(59, Math.max(0, Number(m[2])));
    return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
  }

  // solo números
  const digits = v.replace(/[^0-9]/g, '');
  if (!digits) return '';

  if (digits.length <= 2) {
    const hh = Math.min(23, Math.max(0, Number(digits)));
    return `${String(hh).padStart(2, '0')}:00`;
  }

  const hh = Math.min(23, Math.max(0, Number(digits.slice(0, 2))));
  const mm = Math.min(59, Math.max(0, Number(digits.slice(2, 4))));
  return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
}

function timeSuggestions(query: string, options: string[]) {
  const q = query.trim();
  if (!q) return options.slice(0, 8);

  // Si el usuario tipea "13" → sugerimos 13:00, 13:30, 13:...
  const digits = q.replace(/[^0-9]/g, '');
  if (digits.length === 1 || digits.length === 2) {
    const hh = String(Math.min(23, Math.max(0, Number(digits)))).padStart(2, '0');
    return options.filter((t) => t.startsWith(`${hh}:`)).slice(0, 6);
  }

  // fallback: includes
  const q2 = q.toLowerCase();
  return options
    .filter((t) => t.toLowerCase().includes(q2))
    .slice(0, 10);
}

function TimePicker({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const options = useMemo(() => buildTimeOptions(30), []);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');

  const suggestions = useMemo(() => timeSuggestions(query, options), [query, options]);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <div className="relative">
          <Input
            value={value}
            inputMode="numeric"
            onFocus={() => setOpen(true)}
            onChange={(e) => {
              const raw = e.target.value;
              onChange(raw);
              setQuery(raw);
              setOpen(true);
            }}
            onBlur={() => {
              const n = normalizeTimeInput(value);
              if (n) onChange(n);
              setQuery('');
            }}
            placeholder="HH:MM"
            className="pr-9"
          />
          <Clock className="pointer-events-none absolute right-2 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        </div>
      </PopoverTrigger>

      <PopoverContent align="start" className="w-[260px] p-0">
        <Command>
          <CommandInput
            value={query}
            onValueChange={(v) => {
              setQuery(v);
              // si el usuario escribe acá, también reflejamos en el input principal
              onChange(v);
            }}
            placeholder="Escribí una hora… (ej: 13)"
          />
          <CommandList>
            <CommandEmpty>No hay coincidencias.</CommandEmpty>
            <CommandGroup heading="Sugerencias">
              {suggestions.map((t) => (
                <CommandItem
                  key={t}
                  value={t}
                  onSelect={() => {
                    onChange(t);
                    setQuery('');
                    setOpen(false);
                  }}
                  className="flex items-center justify-between"
                >
                  <span>{t}</span>
                  {value === t && <Check className="h-4 w-4 text-slate-400" />}
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

export default function TaskDetailModal({
  task,
  briefStatusLabel,
  onClose,
  onTaskUpdate,
  onAllDone,
}: Props) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [time, setTime] = useState('09:00');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!task) return;
    setTitle(task.title ?? '');
    setDescription(task.description ?? '');
    setTime(hhmmLocal(task.scheduled_at));
  }, [task?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const dateLabel = useMemo(() => {
    if (!task) return '';
    return new Date(task.scheduled_at).toLocaleString('es-AR', {
      weekday: 'short',
      day: '2-digit',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
    });
  }, [task?.scheduled_at]);

  async function saveEdits() {
    if (!task) return;

    const nextTitle = title.trim();
    if (!nextTitle) return;

    try {
      setSaving(true);

      const normalizedTime = normalizeTimeInput(time);
      if (!normalizedTime || !/^\d{2}:\d{2}$/.test(normalizedTime)) {
        alert('Hora inválida. Ejemplo válido: 13:00 ó 09:30');
        return;
      }

      const dayYMD = toYMD(new Date(task.scheduled_at));
      const nextScheduledAt = buildISOFromLocal(dayYMD, normalizedTime);

      const patch: any = {
        title: nextTitle,
        description: description?.trim() ? description.trim() : null,
        scheduled_at: nextScheduledAt,
      };

      const { data, error } = await supabase
        .from('tasks')
        .update(patch)
        .eq('id', task.id)
        .select('*')
        .single();

      if (error) throw error;

      onTaskUpdate(data as Task);
    } catch (err) {
      console.error('Error al editar tarea', err);
      alert('No se pudo guardar la tarea. Intentá nuevamente.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <AnimatePresence>
      {task && (
        <motion.div
          key={task.id}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[80] flex items-center justify-center bg-black/60 backdrop-blur-md"
          onClick={onClose}
        >
          <motion.div
            initial={{ y: 24, scale: 0.97, opacity: 0 }}
            animate={{ y: 0, scale: 1, opacity: 1 }}
            exit={{ y: 24, scale: 0.97, opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="relative max-h-[90vh] w-full max-w-2xl overflow-hidden rounded-2xl border border-slate-800 bg-gray-800 text-slate-100 shadow-2xl shadow-slate-950/70"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-start justify-between gap-3 border-b border-slate-800 px-5 py-4">
              <div className="min-w-0 space-y-2">
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
                  <span className="inline-flex items-center rounded-full bg-slate-900 px-2 py-0.5">
                    <CalendarDays className="mr-1 h-3 w-3" />
                    {dateLabel}
                  </span>
                  <span className="text-[11px] text-slate-500">
                    Estado: {briefStatusLabel(task.status)}
                  </span>
                </div>
              </div>

              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
                className="rounded-full bg-slate-900 px-3 text-xs text-slate-300 hover:bg-slate-800"
              >
                Cerrar
              </Button>
            </div>

            {/* Body: izquierda (edición) | derecha (checklist) */}
            <div className="grid max-h-[calc(90vh-72px)] grid-cols-1 gap-0 md:grid-cols-[1fr,1.15fr]">
              {/* Left */}
              <div className="border-b border-slate-800 p-5 md:border-b-0 md:border-r">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-[11px] text-slate-400">Título</Label>
                    <Input
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="Título"
                      className="bg-slate-950/40"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-[11px] text-slate-400">Descripción</Label>
                    <Textarea
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      placeholder="Descripción / detalle"
                      className="min-h-[110px] resize-none bg-slate-950/40 text-sm"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="text-[11px] text-slate-400">Hora</Label>
                    <TimePicker value={time} onChange={setTime} />
                    <p className="text-[11px] text-slate-500">
                      Tip: escribí “13” y elegí <span className="text-slate-300">13:00</span> o{' '}
                      <span className="text-slate-300">13:30</span>.
                    </p>
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-2">
                    <Button
                      onClick={saveEdits}
                      disabled={saving || !title.trim()}
                      className="rounded-full"
                    >
                      {saving ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : (
                        <Save className="mr-2 h-4 w-4" />
                      )}
                      Guardar
                    </Button>
                  </div>
                </div>
              </div>

              {/* Right */}
              <div className="min-h-0">
                <TaskChecklistSection
                  taskId={task.id}
                  notes={task.notes ?? null}
                  editable={true}
                  variant="owner"
                  onAllDoneChange={async (allDone) => {
                    if (!allDone) return;
                    const updated = await onAllDone(task);
                    onTaskUpdate(updated);
                  }}
                />
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
