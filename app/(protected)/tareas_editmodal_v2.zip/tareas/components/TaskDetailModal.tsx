'use client';

import { AnimatePresence, motion } from 'framer-motion';
import { CalendarDays, Loader2, Save } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import type { Task } from '@/lib/tasks';
import { supabase } from '@/lib/supabaseClient';
import TaskChecklistSection from '../TaskChecklistSection';
import { buildISOFromLocal, toYMD } from '../date';

type Props = {
  task: Task | null;
  briefStatusLabel: (status: Task['status']) => string;
  onClose: () => void;
  onTaskUpdate: (next: Task) => void;
  onAllDone: (task: Task) => Promise<Task>;
};

function hhmmLocal(iso: string) {
  const d = new Date(iso);
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  return `${hh}:${mm}`;
}

export default function TaskDetailModal({
  task,
  briefStatusLabel,
  onClose,
  onTaskUpdate,
  onAllDone,
}: Props) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [time, setTime] = useState('09:00');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!task) return;
    setTitle(task.title ?? '');
    setDescription(task.description ?? '');
    setTime(hhmmLocal(task.scheduled_at));
  }, [task?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const dateLabel = useMemo(() => {
    if (!task) return '';
    return new Date(task.scheduled_at).toLocaleString('es-AR', {
      weekday: 'short',
      day: '2-digit',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
    });
  }, [task?.scheduled_at]);

  async function saveEdits() {
    if (!task) return;

    const nextTitle = title.trim();
    if (!nextTitle) return;

    try {
      setSaving(true);

      const dayYMD = toYMD(new Date(task.scheduled_at));
      const nextScheduledAt = buildISOFromLocal(dayYMD, time);

      const patch: any = {
        title: nextTitle,
        description: description?.trim() ? description.trim() : null,
        scheduled_at: nextScheduledAt,
      };

      const { data, error } = await supabase
        .from('tasks')
        .update(patch)
        .eq('id', task.id)
        .select('*')
        .single();

      if (error) throw error;

      onTaskUpdate(data as Task);
    } catch (err) {
      console.error('Error al editar tarea', err);
      alert('No se pudo guardar la tarea. Intentá nuevamente.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <AnimatePresence>
      {task && (
        <motion.div
          key={task.id}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[80] flex items-center justify-center bg-black/60 backdrop-blur-md"
          onClick={onClose}
        >
          <motion.div
            initial={{ y: 24, scale: 0.97, opacity: 0 }}
            animate={{ y: 0, scale: 1, opacity: 1 }}
            exit={{ y: 24, scale: 0.97, opacity: 0 }}
            transition={{ duration: 0.18 }}
            className="relative max-h-[90vh] w-full max-w-2xl overflow-hidden rounded-2xl border border-slate-800 bg-gray-800 text-slate-100 shadow-2xl shadow-slate-950/70"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between gap-3 border-b border-slate-800 px-5 py-4">
              <div className="min-w-0 space-y-2">
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
                  <span className="inline-flex items-center rounded-full bg-slate-900 px-2 py-0.5">
                    <CalendarDays className="mr-1 h-3 w-3" />
                    {dateLabel}
                  </span>
                  <span className="text-[11px] text-slate-500">
                    Estado: {briefStatusLabel(task.status)}
                  </span>
                </div>

                {/* Editable fields */}
                <div className="grid gap-2">
                  <input
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full rounded-xl border border-slate-800 bg-slate-950/40 px-3 py-2 text-sm font-semibold text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                    placeholder="Título"
                  />

                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="min-h-[70px] w-full resize-none rounded-xl border border-slate-800 bg-slate-950/40 px-3 py-2 text-xs text-slate-200 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                    placeholder="Descripción / detalle"
                  />

                  <div className="flex items-center gap-2">
                    <label className="text-[11px] text-slate-400">Hora</label>
                    <input
                      type="time"
                      value={time}
                      onChange={(e) => setTime(e.target.value)}
                      className="rounded-lg border border-slate-800 bg-slate-950/40 px-2 py-1 text-xs text-slate-100 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
                    />

                    <button
                      onClick={saveEdits}
                      disabled={saving || !title.trim()}
                      className="ml-auto inline-flex items-center gap-2 rounded-full bg-sky-500/15 px-3 py-1.5 text-xs font-medium text-sky-200 hover:bg-sky-500/20 disabled:opacity-50"
                      title="Guardar cambios"
                    >
                      {saving ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Save className="h-4 w-4" />
                      )}
                      Guardar
                    </button>
                  </div>
                </div>
              </div>

              <button
                onClick={onClose}
                className="rounded-full bg-slate-900 px-2 py-1 text-xs text-slate-400 hover:bg-slate-800 hover:text-slate-100"
              >
                Cerrar
              </button>
            </div>

            <TaskChecklistSection
              taskId={task.id}
              notes={task.notes ?? null}
              editable={true}
              variant="owner"
              onAllDoneChange={async (allDone) => {
                if (!allDone) return;
                const updated = await onAllDone(task);
                onTaskUpdate(updated);
              }}
            />
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
